public class Main {
    public static void main(String[] args) {
        Auto auto1 = new Auto("Tesla", "Model S", 250, 80);
        Moto moto1 = new Moto("Yamaha", "R6", 220, 600);
        Camion camion1 = new Camion("Volvo", "FH16", 180, 20);
        auto1.cargarBateria(10);
        System.out.println();
        Vehiculo[] vehiculos = {auto1, moto1, camion1};
        for (Vehiculo v : vehiculos) {
            v.mostrar();
            System.out.println("------------------------");
        }
    }
}