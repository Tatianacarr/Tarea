public class Camion extends Vehiculo {
    private double cargaMaxima;
    public Camion(String marca,String modelo,int velocidadM,double cargaMaxima){
        super(marca,modelo,velocidadM);
    }
    @Override
    public void mostrar(){
        System.out.println("CAMION");
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Velocidad Maxima: " + velocidadM + " km/h");
        System.out.println("Carga maxima: " + cargaMaxima + " toneladas");
    }
    }
