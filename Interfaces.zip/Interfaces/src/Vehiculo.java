public class Vehiculo {
    protected String marca;
    protected String modelo;
    protected int velocidadM;
    public Vehiculo(String marca,String modelo,int velocidadM){
        this.marca=marca;
        this.modelo=modelo;
        this.velocidadM=velocidadM;

    }
    public void mostrar(){
        System.out.println("Vehiculo:"+marca);
        System.out.println("Modelo:"+modelo);
        System.out.println("Velocidad maxima:"+velocidadM);
    }
}
