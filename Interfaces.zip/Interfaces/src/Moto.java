public class Moto extends Vehiculo{
    private int cilindrada;
    public Moto(String marca, String modelo,int velocidadM,int cilindrada){
        super(marca, modelo, velocidadM);
        this.cilindrada=cilindrada;
    }
    @Override
    public void mostrar(){
        System.out.println("MOTO");
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Velocidad Maxima: " + velocidadM + " km/h");
        System.out.println("Cilindrada: " + cilindrada + " cc");
    }
}
