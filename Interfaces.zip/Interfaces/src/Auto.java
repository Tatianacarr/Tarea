public class Auto extends Vehiculo implements Electrico {

    private int bateria;
    public Auto(String marca, String modelo, int velocidadM, int bateria) {
        super(marca, modelo, velocidadM);
        this.bateria = bateria;
    }
    @Override
    public void cargarBateria(int porcentaje) {

        bateria += porcentaje;

        if (bateria > 100) {
            bateria = 100;
        }

        System.out.println("Bateria cargada al " + bateria + "%");
    }

    @Override
    public int automiaKm() {
        return bateria * 5;
    }

    @Override
    public void mostrar() {
        System.out.println("AUTO ELECTRICO");
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Velocidad Maxima: " + velocidadM + " km/h");
        System.out.println("Bateria: " + bateria + "%");
        System.out.println("Autonomia: " + automiaKm() + " km");
    }
}

