public class Main {

    public static void main(String[] args) {

        EmpleadoPorHora e1 = new EmpleadoPorHora("Carlos", 1, 40, 8);

        EmpleadoPorHora e2 = new EmpleadoPorHora("Ana", 2, 35, 10);
        EmpleadoFijo e3 = new EmpleadoFijo("Luis", 3, 40, 900);

        EmpleadoFijo e4 = new EmpleadoFijo("Maria", 4, 40, 1200);

        EmpleadoComision e5 = new EmpleadoComision("Pedro", 5, 40, 700, 15, 3000);

        EmpleadoComision e6 = new EmpleadoComision("Sofia", 6, 40, 800, 10, 5000);
        Empleado[] empleados = {e1, e2, e3, e4, e5, e6};

        for (Empleado e : empleados) {

            System.out.println("------------------------");
            e.mostrar();
            if (e instanceof Bonificable b) {

                System.out.println("Bono: $" + b.calcularBono());
            }
        }
    }
}
