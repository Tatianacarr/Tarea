public class Main {
    public static void main(String[]args){
        Circulo c1= new Circulo("Rojo",true,5);
        Circulo c2=new Circulo("Verde",false,3);

        Rectangulo r1= new Rectangulo("Amarillo",false,8,2);
        Rectangulo r2= new Rectangulo("Azul",true,8,9);

        TrianguloRectangulo t1=new TrianguloRectangulo("Negro",true,4,3);
        TrianguloRectangulo t2=new TrianguloRectangulo("Morado",true,5,12);

        Figura[] figuras = {c1,c2,r1,r2,t1,t2};
        for (Figura f: figuras){
            f.mostrar();
        }


    }
}