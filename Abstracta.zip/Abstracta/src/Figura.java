public  abstract class Figura {
    protected String color;
    protected boolean rellena;
    public Figura(String color,boolean rellena){
        this.color=color;
        this.rellena=rellena;
    }
    public abstract double calcularArea();
    public abstract double calcularPerimetro();

    public void mostrar(){
        System.out.println("Color:"+color);
        if (rellena){
            System.out.println("Figura rellena: SI");
        }else{
            System.out.println("Figura rellana:NO");
        }
        System.out.println("Area:"+calcularArea());
        System.out.println("Perimetro:"+calcularPerimetro());
    }
}
